name             'backup'
maintainer       'Singapore Universiry'
maintainer_email 'junaidsh@thoughtworks.com'
license          'All rights reserved'
description      'Installs/Configures backup'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
