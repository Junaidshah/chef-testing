#
# Cookbook Name:: backup
# Recipe:: default
#
# Copyright 2016, Singapore University
#
# All rights reserved - Do Not Redistribute
#

cron 'backup' do
  hour '23'
  minute '0'
  command '/root/backup.sh'
  user root
end

template "/root/backup.sh" do
  source "backup.cfg.erb"
  owner "root"
  group "root"
  mode  0755
end

directory "/mnt/backup" do
owner "root"
group "root"
mode "0750"
action :create
end

mount '/mnt/backup' do
  device 'sunfsserver.com:/mirror/backup_uploads'
  fstype 'nfs'
  options 'rw'
  action [:mount, :enable]
end
